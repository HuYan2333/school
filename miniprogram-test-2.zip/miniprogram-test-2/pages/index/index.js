//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    noticeList: [{
      url: "../tk/tk",
      context: "我院2018年招生录取工作圆满结束"
    },
    {
      url: "../tk/tk",
      context: "我院2017年招生录取工作圆满结束"
    },
    {
      url: "../tk/tk",
      context: "我院2016年招生录取工作圆满结束"
    },
    {
      url: "../tk/tk",
      context: "2015年高招录取工作圆满结束"
    },
    {
      url: "../tk/tk",
      context:"我院2015年专接本录取率再创新高"
    }
    ]
  
  },
  //事件处理函数
  xiangqing: function() {
    wx.navigateTo({
      url: '../one-xiangqing/one-xiangqing'
    })
  },
  chakantwo: function () {
    wx.navigateTo({
      url: '../luqujieguo/luqujieguo'
    })
  },
  map:function(){
    wx.navigateTo({
      url: '../ditu/ditu'
    })
  },
  zhangcheng: function () {
    wx.navigateTo({
      url: '../zhangcheng/zhangcheng'
    })
  },
  onLoad: function () {
    
  },

})
