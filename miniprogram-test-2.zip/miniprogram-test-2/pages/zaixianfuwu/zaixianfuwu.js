// pages/zaixianfuwu/zaixianfuwu.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  baokaoliyou1: function () {
    wx.navigateTo({
      url: '../baokaoliyou/baokaoliyou'
    })
  },
  baokaoliyou2: function () {
    wx.navigateTo({
      url: '../baokaoliyou2/baokaoliyou2'
    })
  },
  baokaoliyou3: function () {
    wx.navigateTo({
      url: '../baokaoliyou3/baokaoliyou3'
    })
  },
  baokaoliyou4: function () {
    wx.navigateTo({
      url: '../baokaoliyou4/baokaoliyou4'
    })
  },
  baokaoliyou5: function () {
    wx.navigateTo({
      url: '../baokaoliyou5/baokaoliyou5'
    })
  },
  baokaoliyou6: function () {
    wx.navigateTo({
      url: '../baokaoliyou6/baokaoliyou6'
    })
  },
  zixun: function () {
    wx.navigateTo({
      url: '../zixun/zixun'
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})