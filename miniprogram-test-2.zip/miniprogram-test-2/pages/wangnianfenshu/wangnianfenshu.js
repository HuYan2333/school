// pages/wangnianfenshu/wangnianfenshu.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pic_array: [
      { id: 1, name: '2018' },
      { id: 2, name: '2019' },
    ],
    hx_index: 1,
    place_array: [
      { id: 3, name: '上海' },
      { id: 4, name: '云南' },
      { id: 5, name: '内蒙古' },
      { id: 6, name: '北京' },
      { id: 7, name: '吉林' },
      { id: 8, name: '四川' },
      { id: 9, name: '天津' },
      { id: 10, name: '宁夏' },
      { id: 11, name: '安徽' },
      { id: 12, name: '山东' },
      { id: 13, name: '山西' },
      { id: 14, name: '广东' },

    ],
    dd_index: 0,
    benke_array: [
      { id: 15, name: '本科' },
    ],
    bb_index: 0,
    type_array: [
      { id: 20, name: '体育' },
      { id: 21, name: '综合改革' },
    ],
    tt_index: 0,
    chaxun: true
  },
  bindPickerChange_hx: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value);
    this.setData({   //给变量赋值
      hx_index: e.detail.value,  //每次选择了下拉列表的内容同时修改下标然后修改显示的内容，显示的内容和选择的内容一致
    })
    console.log('自定义值:', this.data.hx_select);
  },
  bindPickerChange_dd: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value);
    this.setData({   //给变量赋值
      dd_index: e.detail.value,
    })
    console.log('自定义值:', this.data.hx_select);
  },
  bindPickerChange_bb: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value);
    this.setData({   //给变量赋值
      bb_index: e.detail.value,
    })
    console.log('自定义值:', this.data.hx_select);
  },
  bindPickerChange_tt: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value);
    this.setData({   //给变量赋值
      tt_index: e.detail.value,
    })
    console.log('自定义值:', this.data.hx_select);
  },
  click: function () {
    this.setData({
      chaxun: !this.data.chaxun
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})