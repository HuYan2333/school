// pages/zixun/zixun.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    place_array: [
      { id: 3, name: '北京' },
      { id: 4, name: '上海' },
      { id: 5, name: '天津' },
      { id: 6, name: '重庆' },
      { id: 7, name: '吉林' },
      { id: 8, name: '四川' },
      { id: 9, name: '黑龙江' },
      { id: 10, name: '宁夏' },
      { id: 11, name: '安徽' },
      { id: 12, name: '山东' },
      { id: 13, name: '山西' },
      { id: 14, name: '广东' },

    ],
    dd_index: 0,
  },
  bindPickerChange_dd: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value);
    this.setData({   //给变量赋值
      dd_index: e.detail.value,
    })
    console.log('自定义值:', this.data.hx_select);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})